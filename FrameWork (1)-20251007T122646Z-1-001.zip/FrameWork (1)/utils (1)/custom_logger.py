import logging
import inspect

def customLogger(logLevel=logging.DEBUG):
    #Provide the file name
    loggerName=inspect.stack()[1][3]
    logger=logging.getLogger(loggerName)

    #set the default logging level
    logger.setLevel(logging.DEBUG)

    #file handler
    fileHandler=logging.FileHandler("automation.log", mode='a')
    fileHandler.setLevel(logLevel)

    formatter = logging.Formatter('%(asctime)s: %(name)s: %(levelname)s: %(message)s',
                                  datefmt='%m/%d/%Y %I:%M:%S %p')
    fileHandler.setFormatter(formatter)
    logger.addHandler(fileHandler)

    return logger
