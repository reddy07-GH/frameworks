import csv

def getCSVData(fileName):
    #create a empty list to collect rows
    rows=[]
    #open the CSV file
    dataFile=open(fileName,'r')
    #creat the CSV reader
    reader=csv.reader(dataFile)
    #skip the header
    next(reader)
    #add rows to the list
    for row in reader:
        rows.append(row)

    return rows