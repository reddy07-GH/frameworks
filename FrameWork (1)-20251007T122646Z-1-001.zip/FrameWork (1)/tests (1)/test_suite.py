import unittest
from tests.test_Login import LoginTests as l1
from tests.test_Login_datadriven import LoginTests as l2
from tests.test_Login_datadriven import LoginTests as l3
from tests.test_users import UserTests

tc1=unittest.TestLoader().loadTestsFromTestCase(l1)
tc2=unittest.TestLoader().loadTestsFromTestCase(l2)
tc3=unittest.TestLoader().loadTestsFromTestCase(l3)
tc4=unittest.TestLoader().loadTestsFromTestCase(UserTests)

smoke=unittest.TestSuite([tc1,tc2,tc3,tc4])
unittest.TextTestRunner(verbosity=2).run(smoke)

