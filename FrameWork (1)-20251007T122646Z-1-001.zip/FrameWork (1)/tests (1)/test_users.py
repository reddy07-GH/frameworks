import pytest
import unittest
from pages.login_page import LoginPage
from pages.users_page import UsersPage
from ddt import ddt,unpack,data
from utils.read_data import getCSVData

@pytest.mark.usefixtures("oneTimeSetUp")
@ddt
class UserTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self,oneTimeSetUp):
        self.login=LoginPage(self.driver)
        self.users=UsersPage(self.driver)

    @data(*getCSVData("C:\\D-Drive\\Training\\Mar07Batch\\FrameWork\\TestData\\usersData.csv"))
    @unpack
    def test_verifyCreateUser(self,firstName,lastName,email,userName,password,retypepassword):
        self.login.validLogin("admin","manager")
        self.users.creatUser(firstName,lastName,email,userName,password,retypepassword)



