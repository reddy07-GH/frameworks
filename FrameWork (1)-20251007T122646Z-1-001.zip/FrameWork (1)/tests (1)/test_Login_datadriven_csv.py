
import unittest
from pages.login_page import LoginPage
import pytest
from ddt import ddt, data, unpack
from utils.read_data import getCSVData

@pytest.mark.usefixtures("oneTimeSetUp")
@ddt
class LoginTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self,oneTimeSetUp):
        self.l = LoginPage(self.driver)


    @data(*getCSVData("C:\\D-Drive\\Training\\Mar07Batch\\FrameWork\\testData.csv"))
    @unpack
    def test_validLogin(self,userName,password,profName):
        self.l.validLogin(userName,password)
        result=self.l.verifyProgileName(profName)
        assert result==True

