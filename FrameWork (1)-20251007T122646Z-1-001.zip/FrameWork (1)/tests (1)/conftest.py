import pytest
from base.webdriverfactory import WebDriverFactory
from pages.login_page import LoginPage
@pytest.yield_fixture(scope="function")
def oneTimeSetUp(request,browser,osType):
    wf=WebDriverFactory(browser)
    driver=wf.openBrowser()
    if request.cls is not None:
        request.cls.driver=driver
    yield driver
    l=LoginPage(driver)
    l.logOut()
    driver.quit()


def pytest_addoption(parser):
    parser.addoption("--browser")
    parser.addoption("--osType")

@pytest.fixture(scope="session")
def browser(request):
    return request.config.getoption("--browser")
@pytest.fixture(scope="session")
def osType(request):
    return request.config.getoption("--osType")
