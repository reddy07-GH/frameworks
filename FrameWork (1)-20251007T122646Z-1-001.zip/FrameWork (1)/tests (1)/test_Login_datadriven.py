from selenium import webdriver
from selenium.webdriver.common.by import By
import unittest
import time
from pages.login_page import LoginPage
import pytest
from ddt import ddt, data, unpack

@pytest.mark.usefixtures("oneTimeSetUp")
@ddt
class LoginTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self,oneTimeSetUp):
        self.l = LoginPage(self.driver)


    @data(("admin","manager","John Doe"),("trainee","trainee","Michelle Long"))
    @unpack
    def test_validLogin(self,userName,password,profName):
        self.l.validLogin(userName,password)
        result=self.l.verifyProgileName(profName)
        assert result==True

