from selenium.webdriver.common.by import By
from base.selenium_driver import SeleniumDriver


class LoginPage(SeleniumDriver):

    def __init__(self,driver):
        super().__init__(driver)
        self.driver=driver

    #locators
    _username="username"
    _password="pwd"
    _loginButton="//a[@id='loginButton']/div"
    _profName="//a[@class='userProfileLink username']"
    _errMsg="//span[@class='errormsg']"
    _logOut="logoutLink"
    def enterUsername(self,username):
        self.enterText(self._username,"id",username)

    def enterPassword(self,password):
        self.enterText(self._password,"name",password)

    def clickOnLogin(self):
        self.elementClick(self._loginButton,"xpath")

    def validLogin(self,username,password):
        self.enterUsername(username)
        self.enterPassword(password)
        self.clickOnLogin()

    def verifyLogin(self):
        self.waitForElementToVisible(self._profName,"xpath")
        result=self.isElementPresent(self._profName,"id")
        return result

    def verifyProgileName(self,profileName):
        self.waitForElementToVisible(self._profName,"xpath")
        actual=self.getElementText(self._profName,"xpath")
        if actual in profileName:
            result=True
        else:
            result=False
        return result

    def verifyLoginError(self,errMsg):
        actual=self.getElementText(self._errMsg,"xpath")
        if actual in errMsg:
            return True
        else:
            return False

    def logOut(self):
        self.elementClick(self._logOut,"id")