from base.selenium_driver import SeleniumDriver


class UsersPage(SeleniumDriver):

    def __init__(self,driver):
        super().__init__(driver)
        self.driver=driver

    _usersTab="//div[@id='container_users']"
    _NewUserButton="//div[@class='components_button  withPlusIcon']"
    _firstName="(//input[@name='firstName'])[2]"
    _lastName="(//input[@name='lastName'])[2]"
    _email="(//input[@name='email'])[2]"
    _userName="(//input[@name='username'])[2]"
    _password="(//input[@name='password'])[2]"
    _retypePassword="(//input[@name='passwordCopy'])[2]"
    _createUserButton="//div[@class='components_button submitBtn']"
    _userNameText="(//table[@class='userNameContainer'])[1]/tbody/tr[1]"


    def creatUser(self,fn,ln,em,un,pwd,rpwd):
        self.waitForElementToVisible(self._usersTab,"xpath")
        self.elementClick(self._usersTab,"xpath")
        self.waitForElementToClick(self._NewUserButton,"xpath")
        self.elementClick(self._NewUserButton,"xpath")
        self.enterText(self._firstName,"xpath",fn)
        self.enterText(self._lastName,"xpath",ln)
        self.enterText(self._email,"xpath",em)
        self.enterText(self._userName,"xpath",un)
        self.enterText(self._password,"xpath",pwd)
        self.enterText(self._retypePassword,"xpath",rpwd)
        self.elementClick(self._createUserButton,"xpath")
        self.waitForElementToVisible(self._userNameText,"xpath")
        actual=self.getElementText(self._userNameText,"xpath")
        if fn in actual:
            return True
        else:
            return False



