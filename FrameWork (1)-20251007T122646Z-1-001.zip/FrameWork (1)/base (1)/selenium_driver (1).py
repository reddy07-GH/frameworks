from selenium.webdriver.common.by import By
from traceback import print_stack
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *
import utils.custom_logger as cl
import time
import os

class SeleniumDriver():

    def __init__(self,driver):
        self.driver=driver
    log=cl.customLogger()

    def getByType(self, locatorType):
        locatorType = locatorType.lower()
        if locatorType == "id":
            return By.ID
        elif locatorType == "name":
            return By.NAME
        elif locatorType == "xpath":
            return By.XPATH
        elif locatorType == "css":
            return By.CSS_SELECTOR
        elif locatorType == "classname":
            return By.CLASS_NAME
        elif locatorType == "linktext":
            return By.LINK_TEXT
        else:
            self.log.info("Locator type " + locatorType + " not correct/supported")
        return False

    def getScreenShot(self,name):
        fileName=name+"_"+str(round(time.time()*1000))+".png"
        currentDirectory=os.path.dirname(__file__)
        screenShotsDir="../screenshots/"
        relativeFileName=screenShotsDir+fileName
        destinationFile=os.path.join(currentDirectory,relativeFileName)
        desinationDirectory=os.path.join(currentDirectory,screenShotsDir)
        try:
            if not os.path.exists(desinationDirectory):
                os.makedirs(desinationDirectory)
            self.driver.save_screenshot(destinationFile)
        except:
            self.log.warning("Failed to take screenshot")
            print_stack()


    def getElement(self, locator, locatorType="id"):
        element = None
        try:
            locatorType = locatorType.lower()
            byType = self.getByType(locatorType)
            element = self.driver.find_element(byType, locator)
            self.log.info("Element Found")
        except:
            self.log.warning("Element not found")
            self.getScreenShot("failToFindElement")
            raise Exception("Element not found")
        return element

    def elementClick(self,locator, locatorType):
        element=None
        try:
            element=self.getElement(locator,locatorType)
            element.click()
            self.log.info("Clicked on the element using locator "+locator+" locatorType "+locatorType)
        except:
            self.getScreenShot("failToClickElement")
            self.log.critical("Failed to click on the element using locator "+locator+" locatorType "+locatorType)
            print_stack()
            raise Exception("Failed to click on the element using locator "+locator+" locatorType "+locatorType)

    def enterText(self,locator,locatorType,data):
        element = None
        try:
            element = self.getElement(locator, locatorType)
            element.send_keys(data)
            self.log.info("Entered text in the element using locator " + locator + " locatorType " + locatorType)
        except:
            self.log.error("Failed to Enter text in the element using locator " + locator + " locatorType " + locatorType)
            self.getScreenShot("failToEnterText")
            print_stack()
            raise Exception("Failed to Enter text in the element using locator " + locator + " locatorType " + locatorType)


    def waitForElementToClick(self, locator, locatorType="id",
                       time_out=10, pollFrequency=0.5):
        element = None
        try:
            byType = self.getByType(locatorType)
            self.log.info("Waiting for maximum :: " + str(time_out) +
                  " :: seconds for element to be clickable")
            wait = WebDriverWait(self.driver, timeout=time_out, poll_frequency=pollFrequency,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            element = wait.until(EC.element_to_be_clickable((byType,
                                                             locator)))
            self.log.info("Element appeared on the web page")
        except:
            self.log.Error("Element not appeared on the web page")
            self.getScreenShot("elementNotFound")
            print_stack()
            raise Exception("Failed to Enter text in the element using locator " + locator + " locatorType " + locatorType)
        return element

    def waitForElementToVisible(self, locator, locatorType="id",
                       time_out=10, pollFrequency=0.5):
        element = None
        try:
            byType = self.getByType(locatorType)
            self.log.info("Waiting for maximum :: " + str(time_out) +
                  " :: seconds for element to be clickable")
            wait = WebDriverWait(self.driver, timeout=time_out, poll_frequency=pollFrequency,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            element = wait.until(EC.visibility_of_element_located((byType,
                                                             locator)))
            self.log.info("Element appeared on the web page")
        except:
            self.log.error("Element not appeared on the web page")
            self.getScreenShot("elementNotFound")
            print_stack()
            raise Exception("Failed to Enter text in the element using locator " + locator + " locatorType " + locatorType)
        return element

    def isElementPresent(self,locator,locatorType):
        element = None
        try:
            element = self.getElement(locator, locatorType)
            if element is not None :
                self.log.info("Element existing, locator " + locator + " locatorType " + locatorType)
                return True
            else:
                self.log.warning("Element not existing, locator " + locator + " locatorType " + locatorType)
                return False
        except:
            self.getScreenShot("elementNotPresent")
            self.log.error( "Failed to find the element using locator " + locator + " locatorType " + locatorType)
            print_stack()
            raise Exception("Failed to Enter text in the element using locator " + locator + " locatorType " + locatorType)


    def getElementText(self, locator, locatorType):
        element = None
        try:
            element = self.getElement(locator, locatorType)
            text=element.text
            self.log.info("Got text of the element using locator " + locator + " locatorType " + locatorType)
            return text
        except:
            self.getScreenShot("elementNotPresent")
            self.log.error("Failed to get text of the element using locator " + locator + " locatorType " + locatorType)
            print_stack()
            raise Exception("Failed to Enter text in the element using locator " + locator + " locatorType " + locatorType)

