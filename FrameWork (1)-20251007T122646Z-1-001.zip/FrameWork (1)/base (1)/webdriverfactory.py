from selenium import webdriver

class WebDriverFactory():

    def __init__(self,browser):
        self.browser=browser

    def openBrowser(self):
        if self.browser=="firefox":
            driver = webdriver.Firefox(executable_path="C:\D-Drive\Training\Mar07Batch\Drivers\geckodriver.exe")
            driver.maximize_window()
            driver.get("http://demo.actiTime.com")
        elif self.browser=="chrome":
            driver = webdriver.Chrome(executable_path="C:\D-Drive\Training\Mar07Batch\Drivers\chromedriver.exe")
            driver.maximize_window()
            driver.get("http://demo.actiTime.com")
        else:
            driver = webdriver.Ie(executable_path="C:\D-Drive\Training\Mar07Batch\Drivers\IEDriverServer.exe")
            driver.maximize_window()
            driver.get("http://demo.actiTime.com")
        return driver